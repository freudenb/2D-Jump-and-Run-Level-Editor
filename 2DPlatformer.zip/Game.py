
import sfml as sf
import Screen
import Player as pl
import Level
import HelpFunctions as hf
import sqlite3 as sql
import GameSettings as gs


class Game(object):
    '''
    Game Klasse kuemert sich um das anzeigen und updaten der Spielobjekte(Level, Player)
    Prueft ausserdem den Highscore
    '''


    def __init__(self, Font):
        
        #Pausenmenue erstellen
        self.__pausenmenu = Screen.initPausenMenu(Font)
        self.__currentLevel = ""
        #Instanze von Spieler Klasse erstellen
        self.__Player = pl.Player("./sprite/player.png")
        #Instanz von Level Klasse erstellen
        self.__Level = Level.Level()
        
        #definiert die Zone die der Spieler erreichen muss um das Level zu beenden
        self.__currentEndZoneRectangle = sf.Rectangle(sf.Vector2(0,0), sf.Vector2(0,0))
        #Variable in der die gemessende Zeit gespeichert wird
        self.__Leveltime = sf.Time()
        
        #Anzeige der Zeit, der Punkte etc.
        self.__hud = HUD(Font)
        
        #Aktueller Highscore
        self.__Highscore = dict()
        
        #Sound laden der abgespielt wird sobald ein neuer Highscore erreicht wurde
        try:    
            self.__newHighscoreSoundBuffer = sf.SoundBuffer.from_file("./sounds/newHighscore.ogg")
        except IOError as e:
            print(e)
            exit(1)
            
        self.__newHighscoreSound = sf.Sound(self.__newHighscoreSoundBuffer)
        
    #reseten des aktuellen Levels und laden des neuen Levels
    def loadLevel(self, levelpfad):
        
        
        self.__currentLevel = levelpfad
        self.__Leveltime = sf.milliseconds(0)
        self.__Player = pl.Player("./sprite/player.png")
        self.__Level = Level.Level()
        self.__Level.loadLevel(levelpfad)
        self.__Player.setPosition(self.__Level.getCurrentActiveCheckpoint().getPosition())
        self.__currentEndZoneRectangle = self.__Level.getEndZoneRectangle()
        self.__Highscore = self.__Level.getHighscore()
        
    #Levellogik updaten
    #Spielerlogik updaten
    def __update(self, elapsedTime, rw):
        
        
        self.__Level.update(self.__Player, elapsedTime, rw)
        self.__Player.update(elapsedTime)
        print("FPS:"+str(1/elapsedTime))
        
    #Anzeige, Levelobjekte und Spieler ins Fenster zeichnen
    def __draw(self, rw):
        
        rw.clear()
        
        self.__hud.draw(rw, self.__Player.score, self.__Player.deaths, self.__Leveltime, self.__Highscore["time"])
        self.__Level.draw(rw)
        self.__Player.draw(rw)
        
        rw.display()
        
       
    
    def run(self, rw):
        
        #misst die Zeit die bei jeden durchlauf der while schleife vergangen ist = Frametime
        clock = sf.Clock()
        
        
        while(rw.is_open):
            #Ansicht auf den Spieler setzen, Spieler immer in der mitte des Fensters
            rw.view.center = self.__Player.getCenter()
            
            for event in rw.events:
                #Eingaben abfragen
                #Falls X angeklickt Fenster schliessen
                if type(event) is sf.CloseEvent:
                    rw.close()
                
                #Pausenmenue aufrufen bei ESCAPE druecken    
                if type(event) is sf.KeyEvent and event.pressed and event.code is sf.Keyboard.ESCAPE:
                    #pausenmenu
                    #Ansichtmitte wieder auf die haelfte des Fensters setzen
                    rw.view.center = sf.Vector2(rw.size.x/2, rw.size.y/2)
                    #Pausenmenue anzeigen, rueckgabe Speichern
                    returnString = self.__pausenmenu.show(rw)
                    clock.restart()
                    
                    #Neustart gewaehlt, Level neu laden
                    if returnString == "Restart":
                        self.loadLevel(self.__currentLevel)
                    #In Levelwahl Menue Springen
                    if(returnString == "Choose Level"):
                        return "Play"
                    #Zureuck ins Hauptmenue
                    if(returnString == "Back to Mainmenu"):
                        return "BACK"
                        
                    
            #Vergangene zeit erhoehen
            self.__Leveltime.milliseconds = self.__Leveltime.milliseconds + clock.elapsed_time.milliseconds
            
            #Objekte aktualisieren
            self.__update(clock.restart().seconds, rw)
            #Objekte anzeigen/zeichnen
            self.__draw(rw)
            
            #pruefen ob Spieler am Ende des Levels angekommen
            if hf.kollision(self.__currentEndZoneRectangle, self.__Player.getBoundingRect()):
                
                #Pruefen ob aktuelle Zeit besser war als der Highscore
                #Gebrauchte Zeit verringern um den Score Wert 1 Score = 500 millisekunden
                self.__Leveltime.milliseconds -= self.__Player.score * 500
                self.__evaluateHighscore()
                
                #Dictionary mit altem Highscore und aktuellem Ergebniss(Zeit,Deaths,Score)
                d = dict({"currentlevelSrc": self.__currentLevel , "LevelTime": self.__Leveltime, "PlayerScore": self.__Player.score , "PlayerDeaths": self.__Player.deaths})
                d.update(self.__Highscore)
                return d
            
            
    def __evaluateHighscore(self):
        
        if self.__Leveltime.milliseconds < self.__Highscore["time"].milliseconds:
            #Neuer Highscore wurde errreicht
            #Sound abspielen
            self.__newHighscoreSound.volume = gs.GameSettings.VOLUME
            self.__newHighscoreSound.play()
            
            #In die SQLite Leveldatei den neue erreichten Highscore eintragen
            db = sql.connect(self.__currentLevel)
            cursor = db.cursor()
            hs = [(self.__Leveltime.milliseconds,self.__Player.score, self.__Player.deaths)]
            cursor.executemany("UPDATE highscore SET time=?,score=?,deaths=?", hs)
            db.commit()
            db.close()
            
       
            
            


class HUD(object):
    
    """
    Anzeige im Spiel
    Zeigt aktuellen Highscore,
    aktuelle Zeit,
    Punkte und
    Tode an
    """
    
    def __init__(self, Font):
        
        self.__highscore = sf.Text()
        self.__highscore.character_size = 18
        self.__highscore.font = Font
        self.__highscore.color = sf.Color.WHITE
        
        
        self.__currenttime = sf.Text()
        self.__currenttime.character_size = 18
        self.__currenttime.font = Font
        self.__currenttime.color = sf.Color.WHITE
        
        
        self.__playerscore = sf.Text()
        self.__playerscore.character_size = 18
        self.__playerscore.font = Font
        self.__playerscore.color = sf.Color.WHITE
        
        self.__playerdeaths = sf.Text()
        self.__playerdeaths.character_size = 18
        self.__playerdeaths.font = Font
        self.__playerdeaths.color = sf.Color.WHITE
            
            
            
    #Zeichnet die Anzeige in das Fenster
    def draw(self, rw, playerscore, playerdeaths, leveltime, highscore):
        
        #Positioniert die Anzeige oben Links in der Ecke mit Abstand 10 in x nd y richtung
        x = (rw.view.center.x - rw.size.x / 2) + 10
        y = (rw.view.center.y - rw.size.y / 2) + 10
        
        self.__highscore.position = sf.Vector2(x,y)
        #wandelt die Zeit in einen String um zum Anzeigen
        self.__highscore.string = "Highscore: "+hf.getTimeString(highscore)
        rw.draw(self.__highscore)
        
        self.__currenttime.position = sf.Vector2(x,y+20)
        self.__currenttime.string = "Time: "+hf.getTimeString(leveltime)
        #Falls Zeit noch unter dem aktuellen Highscore , Zeit gruen anzeigen sonst rot
        if(leveltime.milliseconds < highscore.milliseconds):
            self.__currenttime.color = sf.Color.GREEN
        else:
            self.__currenttime.color = sf.Color.RED
        rw.draw(self.__currenttime)
        
        self.__playerscore.position = sf.Vector2(x,y+40)
        self.__playerscore.string = "Score: "+str(playerscore)
        rw.draw(self.__playerscore)
        
        self.__playerdeaths.position = sf.Vector2(x,y+60)
        self.__playerdeaths.string = "Deaths: "+str(playerdeaths)
        rw.draw(self.__playerdeaths)
        
        
        
        
        
        
           
            
            
    
            
            
        
        
        
        
            
            
            
            
                
                
                
            
            
        