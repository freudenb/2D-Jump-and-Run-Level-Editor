
import math
import sfml as sf
import random
#Prueft ob sich zwei Rechtecke ueberlappen
def kollision(r1, r2):
    
    if r1.left + r1.width < r2.left or r1.left > r2.left + r2.width:
        
        return False
    
    if r1.top + r1.height < r2.top or r1.top > r2.top + r2.height:
        return False
    
    return True
    
#Errechnet die Distanz zwischen zwei Punkten    
def distance(p1, p2):
    
    x = p1.x - p2.x
    y = p1.y - p2.y
    return math.sqrt(x*x + y * y)
#Prueft ob sich ein Rechteck im Sichtbaren Bereich des Fensters befindet
def isOnScreen(rw, rect):
    
    return kollision(sf.Rectangle(sf.Vector2(rw.view.center.x - rw.size.x /2 , rw.view.center.y - rw.size.y /2), sf.Vector2(rw.size.x, rw.size.y)), rect)
    
#Wandelt die sf.Time()  Zeit in einen String um
def getTimeString(time):
    
    s = ""
    minutes = int(time.seconds/60)
    
    s += str(minutes)
    
    s+=":"
    seconds = int(time.seconds)  - (60*minutes) 
    
    if seconds < 10:
        
        s+= "0"
        
    s+= str(seconds) 
    
    s+="."
    
    milliseconds = str(time.milliseconds)[-3:]
    
    s+=milliseconds

    return s

#Erstellt einen Hintergrund mit an zufaelligen Orten platzierten grauen Kreisen 
def createStarBackground(ScreenWidth, ScreenHeight, StarAmount):
        
        #RenderTexture erstellen auf welche gezeichnet wird
        rt = sf.RenderTexture(ScreenWidth, ScreenHeight) 
        rt.clear(sf.Color.TRANSPARENT)
        #Kreis definieren
        circle = sf.CircleShape(1)
        circle.fill_color = sf.Color(168,168,168)
        #errechnen wie viele Kreise gezeichnet werden
        #
        count = (ScreenWidth * ScreenHeight) * StarAmount
        for i in range(0,int(count+1)):
            #wuerfelt eine zufaellige zahl zwischen 0 und Screenbreite oder Hoehe
            circle.position = sf.Vector2(random.randint(0, ScreenWidth), random.randint(0, ScreenHeight))
            rt.draw(circle)
            
            
        rt.display()
        
        return rt