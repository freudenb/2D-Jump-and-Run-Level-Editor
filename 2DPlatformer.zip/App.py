
import sfml as sf
import Screen
import GameSettings
import Game


class App(object):
    """
    Erstellt das Fenster,
    kuemmert sich um das hin und her schalten zwischen den Menues und dem Game
    """
    
    def __init__(self):
        
        #Settings werden aus der SQLite Datenbank geladen
        GameSettings.GameSettings.loadSettings("./settings/settings.sqlite")
        
        #Fenster wird erstellt
        self.__window = sf.RenderWindow(GameSettings.GameSettings.VIDEOMODE, "2d Platformer", sf.Style.FULLSCREEN)
        #self.__window.framerate_limit = GameSettings.GameSettings.FRAMERATE
        self.__window.mouse_cursor_visible = False
        
        try:
            self.mainfont = sf.Font.from_file("./settings/orbitron-black.otf")
        
        except IOError as e:
            print(e)
            exit(1)
        
        #Screens mit den jeweiligen Menues werden erstellt
        self.Titlescreen = Screen.initTitleScreen(self.mainfont, self.__window)
              
        self.Mainmenu = Screen.initMainMenu(self.mainfont, self.__window)
        
        self.Levelmenu = Screen.initLevelMenu(self.mainfont, self.__window)
               
        self.Settingsmenu = Screen.settingsMenu(self.mainfont, self.__window)
        
        self.HighscoreMenu = Screen.Menu(self.mainfont)
        
        self.currentScreen = self.Titlescreen
       
        #Game Klasse wird erstellt
        self.game = Game.Game(self.mainfont)
        
        

        
    
    def run(self):
        #Sobald spiel startet Menuemusic abspielen mit der eingestellten Lautstaerke
        GameSettings.GameSettings.MENUMUSIC.volume = GameSettings.GameSettings.VOLUME     
        GameSettings.GameSettings.MENUMUSIC.play()
        
        while(self.__window.is_open):
            #Den Mittelpunkt der Ansicht auf die Mitte des Fensters setzen
            self.__window.view.center = sf.Vector2(self.__window.size.x /2 , self.__window.size.y / 2)
            #aktuell ausgewaehltes Menue anzeigen und bei neu Wahl den Rueckgabewert in der Variable returnString speichern
            returnString = self.currentScreen.show(self.__window)
            
       
            
            #Fenster schliessen Programm beenden
            if returnString == "Quit":
                self.__window.close()
        
            #Falls gerade im Levelmenue und dort ein Menuepunkt ausgewaehlt
            if self.currentScreen is self.Levelmenu:
                   
                #Falls nicht BACK gewaehtl wurde wurde ein Level ausgewaehlt    
                if returnString != "BACK":
                    
                    #Das Level aus der entsprechenden SQLite Datenbank laden
                    self.game.loadLevel("./levels/"+returnString+".sqlite")
                    #Menue Musik anhalten
                    GameSettings.GameSettings.MENUMUSIC.stop()
                    
                    #Spielmusik abspielen
                    GameSettings.GameSettings.GAMEMUSIC.volume = GameSettings.GameSettings.VOLUME
                    GameSettings.GameSettings.GAMEMUSIC.play()
                    
                    #Spiel starten und bei abbruch ReturnString speichern
                    returnString = self.game.run(self.__window)
                    #nach abbruch Spielmusik wieder stoppen
                    GameSettings.GameSettings.GAMEMUSIC.stop()
                    
                    #Falls die Rueckgabe ein dictionary war wurde das Level erfolgreich beendet und die aktuell erreichte Zeit zureckgegeben
                    if type(returnString) is dict:
                        
                        GameSettings.GameSettings.MENUMUSIC.play()
                        #Highscore Menue wird erstellt mit der aktuellen Zeit und der bisherigen Bestzeit
                        self.HighscoreMenu = Screen.initHighscoreMenu(self.mainfont, returnString, self.__window)
                        #aktueller Screen auf Highscoremenue stellen
                        self.currentScreen = self.HighscoreMenu
            
            #Ins LevelwahlMenue springen
            if returnString == "Play":
                self.currentScreen = self.Levelmenu
                
                
            #In die Optionen springen
            if returnString == "Option":
                self.currentScreen = self.Settingsmenu
                
            
            #Zurueck zum Hauptmenue
            if returnString == "BACK" or returnString == "Back to Mainmenu" or returnString == "press any key":
                
                #Menuemusik abspielen
                GameSettings.GameSettings.MENUMUSIC.volume = GameSettings.GameSettings.VOLUME
                if  GameSettings.GameSettings.MENUMUSIC.status is not sf.Music.PLAYING:
                    GameSettings.GameSettings.MENUMUSIC.play()
                self.currentScreen = self.Mainmenu
                
                
                
            
            
       
                
                
            
                
       
            
if __name__ == '__main__':    
    app = App()
    app.run() 
    
        
    
