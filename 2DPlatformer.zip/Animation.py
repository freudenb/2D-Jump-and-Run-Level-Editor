
import sfml as sf

class Animation(object):
    '''
    Animationsklasse 
    Sprite Sheet Animation abspielen
    Legt fest welcher ausschnit eines Sprite Sheets gerade angezeigt wird
    
    
    '''


    def __init__(self, Frames, Speed, Width, Height, X, Y, startFrame = 0.0):
        
        #ANimation laueft
        self.__isRunning = False
        #Wie viele Frames die Animation hat
        self.__Frames = Frames
        #Wie schnell die Animaiton abluaeft
        self.__Animationspeed = Speed
        #Breite eines Animatios Frame
        self.__FrameWidth = Width
        #Hoehe eines Animations Frame
        self.__FrameHeight = Height
        #X Position des Frames auf dem Sprite Sheet
        self.__FramePositionX = X
        #Y Position des Frames auf dem Sprite Sheet
        self.__FramePositionY = Y
        #Anfangs Frame
        self.__currentFrame = startFrame
        
    #schauen ob laueft
    def isRunning(self):
        return self.__isRunning
    #abspielen
    def play(self):
        
        self.__isRunning = True
        
    #stoppen   
    def stop(self):
        
        self.__isRunning = False
        
    #aktualisieren   
    def update(self,Sprite , elapsedTime):
        
        #falls laueft
        if self.isRunning():
            
            #falls letztes Frame erreicht auf das erste springen
            if self.__currentFrame > self.__Frames:
                self.__currentFrame = 0
             
            #Ausschnit des Sprite Sheet definieren
                
            Sprite.texture_rectangle = sf.Rectangle(sf.Vector2(int(self.__currentFrame) * self.__FrameWidth + self.__FramePositionX, self.__FramePositionY), sf.Vector2(self.__FrameWidth, self.__FrameHeight))
            #Aktuelles Frame erhoehen
            self.__currentFrame += self.__Animationspeed * elapsedTime
            



class AnimationHandler(object):
    
    """
    Enthaelt ein Dictionary mit Animationen
    Ermoeglicht ueber angabe des Keys im Dictionary eine Animation abzuspielen
    """
    
    def __init__(self):
        
        self.__Animations = dict()
        self.__currentAnimationKey = str
        self.__hasRunningAnimation = False
    
    def addAnimation(self, key, Animation):
        #Neue Animation in das Dictionary eintragen
        self.__Animations[key] = Animation
        
    
    def play(self, key):
        #Falls eine Animation bereits laeuft diese erst anhalten
        if self.__hasRunningAnimation:   
            self.__Animations[self.__currentAnimationKey].stop()
    
        #aktuell abgespiele Animation vermerken
        self.__currentAnimationKey = key
        #Animation starten
        self.__Animations[self.__currentAnimationKey].play()
        self.__hasRunningAnimation = True
        
    
    def stopCurrentAnimation(self):
        #aktuell laufende Animation stoppen
        if self.__hasRunningAnimation:
        
            self.__Animations[self.__currentAnimationKey].stop()
            self.__hasRunningAnimation = False
            
            
    def updateAnimation(self, Sprite, elapsedTime):
        #Animation aktualisieren
        if self.__hasRunningAnimation:
            
            self.__Animations[self.__currentAnimationKey].update(Sprite,elapsedTime)
            
    def hasPlayingAnimation(self):
        
        return self.__hasRunningAnimation
        
        
        
        
    
    
            
            
            
         
        
        
        