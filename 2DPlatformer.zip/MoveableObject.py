
import sfml as sf

class MoveableObject(object):
    '''
    Kuemmert sich um das Bewegen des Objekts
    Veraendert die Position auf Basis der Geschwindigkeit
    '''


    def __init__(self, position = sf.Vector2(0.0,0.0), velocity = sf.Vector2(0.0,0.0), acceleration = sf.Vector2(0.0,0.0)):
               
        self.__position = position
        self.__velocity = velocity
        self.__acceleration = acceleration
        
    
    def setPosition(self, p):
        
        self.__position = sf.Vector2(p.x,p.y)
    
    def setPositionX(self, px):
        self.__position.x = px
        
    def setPositionY(self, py):
        self.__position.y = py
        
    def getPosition(self):
        return self.__position
    
    def setVelocityX(self, vx):
        self.__velocity.x = vx
        
    def setVelocityY(self, vy):
        self.__velocity.y = vy
    
    def setVelocity(self, v):
        self.__velocity = sf.Vector2(v.x,v.y)
        
    def getVelocity(self):
        return self.__velocity
    
    def setAccelerationX(self, ax):
        self.__acceleration.x = ax
        
    def setAccelerationY(self, ay):
        self.__acceleration.y = ay

    def setAcceleration(self, a):
        self.__acceleration = sf.Vector2(a.x,a.y)
        
    def getAcceleration(self):
        return self.__acceleration
    
    def move(self, elapsedTime):
        #Geschwindigkiet um die Beschleunigung erhoehen
        self.setVelocityX(self.getVelocity().x + self.getAcceleration().x)
        self.setVelocityY(self.getVelocity().y + self.getAcceleration().y)
        #Position um die Geschwindigkeit erhoehen
        self.setPositionX(self.getPosition().x + self.getVelocity().x * elapsedTime)
        self.setPositionY(self.getPosition().y + self.getVelocity().y * elapsedTime)
        
        self.setAcceleration(sf.Vector2(0,0))
        
    def applyAcceleration(self, a , elapsedTime):
        
        self.setAccelerationX(self.getAcceleration().x + a.x * elapsedTime)
        self.setAccelerationY(self.getAcceleration().y + a.y * elapsedTime)
        
        
        
        