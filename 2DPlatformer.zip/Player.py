
import sfml as sf
import GameSettings as gs
import Animation
import MoveableObject
import HelpFunctions as hf


class Player(MoveableObject.MoveableObject, Animation.AnimationHandler):
    '''
    Abgeleitet von MoveableObject und AnimationHandler
    Player Klasse vearbeitet die Eingaben
    Prueft Kollision mit Platformen und setzt Spieler Variablen entpsrechend
    Spielt animationen ab
    
    '''


    def __init__(self, TextureSrc):
        
        MoveableObject.MoveableObject.__init__(self)
        Animation.AnimationHandler.__init__(self)
        
        #laden der Spieler Textur und des Jumpsounds
        try:
            self.__Texture = sf.Texture.from_file(TextureSrc)
            self.__soundBuffer = sf.SoundBuffer.from_file("./sounds/jump1.ogg")
        except IOError as e:
            print(e)
            exit(1)
        
        
        self.__Sprite = sf.Sprite(self.__Texture)
        self.__Sprite.texture_rectangle = sf.Rectangle(sf.Vector2(0, 2*48), sf.Vector2(32,48))
        
        #Flags fuer den Status des Spielers
        self.__isJumping = False
        self.__isKollisionLeft = False
        self.__isKollisionRight = False
        self.__isKollisionTop = False
        self.__isOnGround = False
        self.__isOnMovingPlatform = False
        
        
        self.__JumpSound = sf.Sound(self.__soundBuffer)
        
        self.score = 0
        self.deaths = 0
         #__init__(self, Frames, Speed, Width, Height, X, Y, startFrame = 0.0):
        #Animationen hinzufuegen mit bestimmten Key im Dictionary zum spaeteren abspielen
        self.addAnimation("left", Animation.Animation(4,10,32,48,0,48))
        self.addAnimation("right", Animation.Animation(4,10,32,48,0,96))
    
    #Breite des SPielers
    def getWidth(self):
        return self.__Sprite.global_bounds.width
    #Hooehe
    def getHeight(self):
        return self.__Sprite.global_bounds.height
    
    #Absoluter Mittelpunkt
    def getCenter(self):
        return sf.Vector2(self.getPosition().x + self.getWidth()/2, self.getPosition().y + self.getHeight()/2)
    #Kollisionsrechteck zuruckgeben
    def getBoundingRect(self):
        return sf.Rectangle(sf.Vector2(self.getPosition().x, self.getPosition().y), sf.Vector2(self.getWidth(), self.getHeight()))
        
                
    def update(self, elapsedTime):
        
        #Sobald die Taste fuer Links gedrueck wird nach Links laufen
        # nur wenn auf Boden und nicht im SPrung
        if sf.Keyboard.is_key_pressed(gs.GameSettings.LEFT) and self.__isOnGround and self.__isJumping is False:
            #Nach links bewegen durch setzen der Geschwindigkeit
            self.setVelocityX(-gs.GameSettings.PLAYERSPEED)
            #Animation nach links laufen abspielen
            self.play("left")
            
        #das selbe wie fuer links nur nach rechts     
        if sf.Keyboard.is_key_pressed(gs.GameSettings.RIGHT) and self.__isOnGround and self.__isJumping is False:
           
            self.setVelocityX(gs.GameSettings.PLAYERSPEED)
            self.play("right")
            
        #sobald wie nichts gedrueckt wurde Spieler anhalten
        #nur wenn auf dem Boden und auf keiner Beweglichen Platform
        if sf.Keyboard.is_key_pressed(gs.GameSettings.RIGHT) is False and sf.Keyboard.is_key_pressed(gs.GameSettings.LEFT) is False and self.__isOnGround:
            
            if self.__isOnMovingPlatform is False:
                self.setVelocityX(0)
            #Animation stoppen   
            self.stopCurrentAnimation()
        
        #Sobald Sprungtaste gerueckt und gerade auf dem Boden, Spieler springen             
        if sf.Keyboard.is_key_pressed(gs.GameSettings.JUMPBUTTON) and self.__isOnGround:
            
            #Spieler anhalten
            self.setVelocity(sf.Vector2(0,0))
            self.setAcceleration(sf.Vector2(0,0))
            self.stopCurrentAnimation()
            
            #Falls gleichzeigig nach links gedrueckt wird Spieler nach links springen
            if sf.Keyboard.is_key_pressed(gs.GameSettings.LEFT):
                self.setAcceleration(sf.Vector2(-gs.GameSettings.PLAYERSPEED * 0.75, gs.GameSettings.PLAYERJUMPSPEED))
            
            #Falls gleichzeitig nach rechts gedrueckt wird Spieler nach rechts springen   
            elif sf.Keyboard.is_key_pressed(gs.GameSettings.RIGHT):
                self.setAcceleration(sf.Vector2(gs.GameSettings.PLAYERSPEED * 0.75, gs.GameSettings.PLAYERJUMPSPEED))
            #Ansonsten nur nach oben Springen    
            else:
                self.setAcceleration(sf.Vector2(0, gs.GameSettings.PLAYERJUMPSPEED))
                #self.applyAcceleration(sf.Vector2(0, gs.GameSettings.PLAYERJUMPSPEED * elapsedTime), elapsedTime)
           
            #Sprungsound abspielen
            self.__JumpSound.volume = gs.GameSettings.VOLUME
            self.__JumpSound.play()
            #Status Springen auf True
            self.__isJumping = True
            self.__isOnGround = False
            self.__isOnMovingPlatform = False
            
        #Falls Spieler gerade im Sprung und rechts oder links gedrueckt spieler um 75% der Speilergeschwindigkeit in die entsprechende Richtung bewegen    
        if sf.Keyboard.is_key_pressed(gs.GameSettings.LEFT) and self.__isJumping:
            self.setVelocityX(-gs.GameSettings.PLAYERSPEED * 0.75)
            self.__Sprite.texture_rectangle = sf.Rectangle(sf.Vector2(0,48), sf.Vector2(32,48))
        
        if sf.Keyboard.is_key_pressed(gs.GameSettings.RIGHT) and self.__isJumping:
            self.setVelocityX(gs.GameSettings.PLAYERSPEED * 0.75)
            self.__Sprite.texture_rectangle = sf.Rectangle(sf.Vector2(0,96), sf.Vector2(32,48))
        
        #Fall Spieler wieder geladnet , Sprung abbrechen          
        if self.__isOnGround and self.__isJumping:
            
            self.__isJumping = False
        
        #Falls Spieler in der Luft, Schwerkraft auf ihn wirken lassen
        if self.__isOnGround is False and self.__isOnMovingPlatform is False:
            
            self.applyAcceleration(sf.Vector2(0,gs.GameSettings.GRAVITY), elapsedTime)
        #Falls Spieler auf dem Boden oder BeweglicherPlatform keine Schwerkraft mehr auf ihn wirken lassen             
        if self.__isOnGround and self.__isOnMovingPlatform is False:
            
            self.setVelocityY(0)
        
        #Falls Spieler an der linken Seite mit Objekt Kollidiert und Geschwindigkeits Vektor auch in diese Richtung zeigt 
        #Spieler nicht weiter nach links bewegen lassen 
        if self.__isKollisionLeft and self.getVelocity().x < 0:
            self.setVelocityX(0)
        #Das selbe wie fuer links    
        if self.__isKollisionRight and self.getVelocity().x > 0:
            self.setVelocityX(0)
            
        #Spieler bewegen
        self.move(elapsedTime)
        #Sprite des Spielers auf die aktuelle Position setzen
        self.__Sprite.position = self.getPosition()
        #Animationen aktuallisieren , naechstes Frame etc.
        self.updateAnimation(self.__Sprite, elapsedTime)
        
        self.__isKollisionLeft = False
        self.__isKollisionRight = False
        self.__isOnGround = False
        self.__isKollisionTop = False
        self.__isOnMovingPlatform = False
        
    #Spieler anzeigen
    def draw(self, rw):
        
        rw.draw(self.__Sprite)
    #Punkte aendern mit Uebergebenen Wert    
    def changeScoreBy(self, s):
        self.score += s
        
    def changeDeathsBy(self, d):
        self.deaths += d
        
    #Prueft ob Spieler an der unteren Seite sich mit einem anderen Rechteck ueberlappt
        
    def checkKollisionBottom(self, Rect):
        
        #Unteres Kollsiions Rechteck wird erstellt vom SPieler
        #Rechteck befindet sich an der unteren Kante mittig mit 1x1 mass
        r = sf.Rectangle(sf.Vector2(self.getPosition().x + (self.getBoundingRect().width-1)/2, self.getPosition().y + self.getBoundingRect().height -1), sf.Vector2(1,1))
    
        return hf.kollision(r, Rect)
        
    def checkKollisionLeft(self, Rect):
        
        #Linkes Kollisions Rechteck wird erstellt
        #Linke Kante mit Hoehe 2 Pixel weniger und 1 Pixel tiefer
        r = sf.Rectangle(sf.Vector2(self.getPosition().x, self.getPosition().y + 1), sf.Vector2(1, self.getBoundingRect().height -2))
        
        return hf.kollision(r, Rect)
        
        
    def checkKollisionRight(self, Rect):
        
        #Rechte Kante mit Hoehe 2 Pixel weniger und 1 Pixel tiefer
        r = sf.Rectangle(sf.Vector2(self.getPosition().x + self.getBoundingRect().width - 1, self.getPosition().y + 1), sf.Vector2(1, self.getBoundingRect().height -2))
        
        return hf.kollision(r, Rect)
    
    def checkKollisionTop(self, Rect):
        
        #Obere Kante mittig mit 1x1 mass
        r = sf.Rectangle(sf.Vector2(self.getPosition().x + (self.getWidth() - 1)/2, self.getPosition().y), sf.Vector2(1,1))
        return hf.kollision(r, Rect)
    
    #Prueft jede Seite und setzt die Flags    
    def checkKollisionWithRect(self, Rect):
        
        
        if self.checkKollisionBottom(Rect):
            self.setPosition(sf.Vector2(self.getPosition().x, Rect.top - self.getBoundingRect().height ))
            self.__isOnGround = True
            
        
        if self.checkKollisionLeft(Rect):
            self.__isKollisionLeft = True
        
        if self.checkKollisionRight(Rect):
            self.__isKollisionRight = True
            
        if self.checkKollisionTop(Rect):
            
            self.__isKollisionTop = True
            #Falls oben angestossen, Geschwindigkeit umkehren
            self.setVelocityY(-self.getVelocity().y)
            
    def checkKollisionWithMovingPlatform(self, MovingPlatform):
        
        self.checkKollisionWithRect(MovingPlatform.getBoundingRect())
        #Falls Spieler auf beweglicher Platform
        
        if self.checkKollisionBottom(MovingPlatform.getBoundingRect()):
            #Spieler uebernimmt die Geschwindigkeit der beweglichen Platform
            #um darauf stehen zu bleiben
            self.setVelocity(MovingPlatform.getVelocity())
            self.__isOnMovingPlatform = True 

 
        
        
        
        