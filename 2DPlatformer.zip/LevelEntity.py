
import MoveableObject
import sfml as sf
import math
import HelpFunctions as hf


class LevelEntity(MoveableObject.MoveableObject):
    '''
    Einfache Levelobjekte
    Kuemmert sich um das Anzeigen der Levelobjekte
    
    '''


    def __init__(self, width, height, color, position, velocity = sf.Vector2(0,0)):
        
        MoveableObject.MoveableObject.__init__(self, position, velocity)
        
        self.__width = width
        self.__height = height
        self._color = color
        #Rechteck erstellen welches angezeigt wird
        self._rectangle = sf.RectangleShape()
        self._rectangle.size = sf.Vector2(self.__width, self.__height)
        self._rectangle.position = self.getPosition()
        #Rahmen mit Breite 1 px
        self._rectangle.outline_thickness = 1
        #Rahmenfarbe mit der angegebenen Farbe
        self._rectangle.outline_color = self._color
        #Alpha der angegebnene Farbe auf 64 setzen
        c = self._color
        c.a = 64
        #Neu definierte Farbe als Fuellfarbe setzen
        self._rectangle.fill_color = c
    
    #Absoluter Mittelpunkt
    def getCenter(self):
        return sf.Vector2(self.getPosition().x + self.__width /2 , self.getPosition().y + self.__height/2)
    #KollsiionsRechteck
    def getBoundingRect(self):
        return sf.Rectangle(sf.Vector2(self.getPosition().x , self.getPosition().y), sf.Vector2(self.__width, self.__height))
    #Anzeigen des Objektes mittels definierten Rechteck    
    def drawRect(self, rw):
        self._rectangle.position = self.getPosition()
        rw.draw(self._rectangle)
    #Anzeige des Objekts mittels einer Textur   
    def drawSprite(self, rw, Texture):
        
        s = sf.Sprite(Texture)
        s.position = self.getPosition()
        s.texture_rectangle = sf.Rectangle(sf.Vector2(0,0), sf.Vector2(self.__width, self.__height))
        
        rw.draw(s)


class MovingPlatform(LevelEntity):
    
    """
    Bewegliche Platform
    Bewegt sich zwischen zwei Punkten hin und her
    Updatet die Platform
    Zeigt Platform an
    """
    
    def __init__(self, velocity, toPoint, width, height, color, position):
        LevelEntity.__init__(self, width, height, color, position)
        #Zwei Punkte zwischen denen sich in und her bewegt wird
        self.__point1 = self.getCenter()
        self.__point2 = toPoint
        #Punkt zu dem sich aktuell bewegt wird
        self.__currentTarget = self.__point2
        self.__velocity = velocity
        
        #Geschwindigkeits Vektor berechnen
        self.setVelocity(self.__calcVelocity())
        
    def update(self, player, elapsedTime):
        
        #Wenn bei aktuellen Zielpunkt angekommen, aktuelles Target auf den jeweiligen anderen Punkt setzen
        if hf.distance(self.getCenter(), self.__currentTarget) < 2:
            
            if self.__currentTarget is self.__point1:
                self.__currentTarget = self.__point2
                
            else:
                self.__currentTarget = self.__point1
            
            #Geschwindigkeits Vektor umkehren
            self.setVelocity(-self.getVelocity())
            
            x = player.getCenter().x
            y = player.getPosition().y + player.getBoundingRect().height
            
            px = self.getCenter().x
            py = self.getPosition().y
            
            #Bei Umkehren die Geschwindigkeit des Spielers  falls uaf Platform neu setzen
            if abs(py - y) <= 2 and hf.distance(sf.Vector2(x,y), sf.Vector2(px,y)) <= self.getBoundingRect().width/2 + player.getBoundingRect().width/2:
                player.setVelocity(self.getVelocity())
                
        
            
           
                            
        #Platform bewegen
        self.move(elapsedTime)
        
        
          
    def __calcVelocity(self):
            #Subtrahiert die Vektorren
            x12 = self.__currentTarget.x - self.getCenter().x 
            y12 = self.__currentTarget.y - self.getCenter().y 
            #errechnet Laenge des Vektors
            h12 = math.sqrt(x12* x12 + y12 * y12)
            
            #Erstellt Einheitsvektor und skaliert diesen mit der gewuenschten Geschwindigkeit
            try:
                x12 = (x12 / h12) * self.__velocity 
                y12 = (y12 / h12) * self.__velocity
            except ZeroDivisionError:
                x12 = 0
                y12 = 0
                
            return sf.Vector2(x12  ,y12)
        
        
class Pickup(LevelEntity):
    """
    Einsammelbares Objekt
    Rotiert sich um die eigene Achse
    
    """
    
    def __init__(self, width, height, color, position, angleVelocity = 200):
        LevelEntity.__init__(self, width, height, color, position)
        
        self.__angle = 0.0
        self.__angleVelocity = angleVelocity
        #Setzt den Ursprung auf den Mittelpunkt des Rechtecks
        self._rectangle.origin = sf.Vector2(self.getBoundingRect().width /2 , self.getBoundingRect().height /2)
        
     
        
    def update(self, elapsedTime):
        #Winkel erhoehen mit Winkelgeschwindigkeit
        self.__angle += self.__angleVelocity * elapsedTime
        #Rotation des Pickups setzen
        self._rectangle.rotation = self.__angle
    
    #Pickup anzeigen   
    def draw(self, rw):
      
        
        rw.draw(self._rectangle)
        

class StarBackground(object):
    
    """
    Erstellt den SPiel Hintergrund
    Platziert an zufaelligen Punkten weisse Kreise 
    
    """
    
    def __init__(self):
        
        
        self.__backgroundImageWidth = 960
        self.__backgroundImageHeight = 960
        
        #erstellt die Textur mit Kreisen
        self.__StarBackground = hf.createStarBackground( self.__backgroundImageWidth,  self.__backgroundImageHeight, 0.0005)
        self.__StarBackgroundSprite = list()
        
        #Kachelt die Textur 11 mal aneinander in x Richtung
        #Springt dann eine Zeile Runter in Y Richtung und kachelt wieder 11 mal in X Richtung die Sprites aneinander usw.
        k = 0
        for i in range(0, 11):
            
            j = 0
            
            for u in range(0,11):
                self.__StarBackgroundSprite.append(sf.Sprite(self.__StarBackground.texture))
                self.__StarBackgroundSprite[len(self.__StarBackgroundSprite)-1].position = sf.Vector2((self.__StarBackgroundSprite[len(self.__StarBackgroundSprite)-1].global_bounds.width*j) - self.__backgroundImageWidth,(self.__StarBackgroundSprite[len(self.__StarBackgroundSprite)-1].global_bounds.height*k) - self.__backgroundImageHeight)
                j += 1
            
            
            k+=1
            
        
          

    
    def update(self, elapsedTime):
        
        pass
            
       
        
    #Zeichnet den Kompletten Hintergrund    
    def draw(self, rw):
        
        for s in self.__StarBackgroundSprite:
            rw.draw(s)
    

         
            
            
        
         
        
        
        
        

        
        