
import sfml as sf
import GameSettings as gs

import LevelEntity as le
import HelpFunctions as hf
import sqlite3 as sql

class Level(object):
    '''
    Levelklasse
    verwaltet alle Levelobjekte
    Prueft Spielerkollsision mit Levelobjekt
    Laedt Levelobjekte aus SQLite Datenbank
    '''


    def __init__(self):
        
        #Objektlisten
        #Bewegliche Platformen
        self.__MovingPlatform = list()
        #Starre Platformen
        self.__StaticPlatform = list()
        #Einsammelbare Objekte
        self.__Pickups = list()
        #Checkpoints
        self.__Checkpoints = list()
        #Zonen in denen der Spieler stribt
        self.__Deathzones = list()
        #Zone die das Level beendet
        self.__Endzone =  le.LevelEntity(0,0,sf.Color(0,0,0), sf.Vector2(0,0))
        
          
        try:    
            self.__cpActiveTexture = sf.Texture.from_file("./sprite/cpactive.png")
            self.__cpInActiveTexture = sf.Texture.from_file("./sprite/cpinactive.png")
            self.__endzoneTexture = sf.Texture.from_file("./sprite/endzone.png")
            self.__PickupSoundBuffer = sf.SoundBuffer.from_file("./sounds/pickup.ogg")
            self.__DeathSoundBuffer = sf.SoundBuffer.from_file("./sounds/pop.ogg")
            self.__CheckpointActiveSoundBuffer = sf.SoundBuffer.from_file("./sounds/newHighscore.ogg")
            
        except IOError as e:
            print(e)
            exit(1)
            
            
        
        self.__HighscoreTime = sf.Time()
        self.__HighscoreScore = 0
        self.__HighscoreDeaths = 0
        
        
        self.__PickupSound = sf.Sound(self.__PickupSoundBuffer)
        
        
        self.__DeathSound = sf.Sound(self.__DeathSoundBuffer)
        
        
        self.__CheckpointActiveSound = sf.Sound(self.__CheckpointActiveSoundBuffer)
        
        self.__currentActiveCheckpoint = le.LevelEntity(0,0,sf.Color(0,0,0), sf.Vector2(0,0))
        
        self.__StarBackground = le.StarBackground()
        
       
    
    def update(self, player, elapsedTime, rw):
        #Bewegliche Objekte updaten
        #Kollsion mit Spieler pruefen
        for p in self.__Pickups:
            p.update(elapsedTime)
        
        
        for mp in self.__MovingPlatform:
            mp.update(player, elapsedTime)
            if hf.isOnScreen(rw, mp.getBoundingRect()):
                player.checkKollisionWithMovingPlatform(mp)
            
        
        for sp in self.__StaticPlatform:
            
            if hf.isOnScreen(rw, sp.getBoundingRect()):
                player.checkKollisionWithRect(sp.getBoundingRect())
            
        
        self.checkKollisionWithCheckpoint(player)
        self.checkKollisionWithPickup(player)
        self.checkKollisionWithDeathzone(player)
        
      
       
        
        
        
    def draw(self, rw):
        #Alle Objekte anzeigen
        self.__StarBackground.draw(rw)
        
        
        for cp in self.__Checkpoints:
            
            if hf.isOnScreen(rw, cp.getBoundingRect()):
                
                if self.__currentActiveCheckpoint is cp:
                    cp.drawSprite(rw,self.__cpActiveTexture)
                else:
                    cp.drawSprite(rw,self.__cpInActiveTexture)
         
    
        for sp in self.__StaticPlatform:
            
            if hf.isOnScreen(rw, sp.getBoundingRect()):
                sp.drawRect(rw)
            
        for mp in self.__MovingPlatform:
            
            if hf.isOnScreen(rw, mp.getBoundingRect()):
                mp.drawRect(rw)
            
            
        for p in self.__Pickups:
        
            if hf.isOnScreen(rw, p.getBoundingRect()):
                p.draw(rw)
            
        self.__Endzone.drawSprite(rw, self.__endzoneTexture)
      
        #alle objekte zeichnen
        
    def loadLevel(self, Levelpfad):
        #Alle Objekte aus SQLite Datenbank laden
        #Highscore aus SQLite Datenbank laden
           
        db = sql.connect(Levelpfad)
        db.row_factory = sql.Row
        cursor = db.cursor()
        cursor.execute("SELECT * FROM levelobjekte")
        db.commit()
        result = cursor.fetchall()
        
        
        #Objekte in die entsprechenden Listen eintragen
        currentObjektList = list()
        for r in result:
            
            
            
            if r["Typ"] == "Endzone":
                self.__Endzone = le.LevelEntity(r["Width"], r["Height"], sf.Color(r["ColorR"], r["ColorG"], r["ColorB"]), sf.Vector2(r["X"], r["Y"]))
                
            if r["Typ"] == "MovingPlatform":
                self.__MovingPlatform.append(le.MovingPlatform(r["Velocity"],sf.Vector2(r["PointToX"], r["PointToY"]),r["Width"], r["Height"], sf.Color(r["ColorR"], r["ColorG"], r["ColorB"]), sf.Vector2(r["X"], r["Y"])))
            
                
            if r["Typ"] == "StaticPlatform":
                currentObjektList = self.__StaticPlatform
                
            if r["Typ"] == "Deathzone":
                currentObjektList = self.__Deathzones
            
            if r["Typ"] == "Checkpoint":
                currentObjektList = self.__Checkpoints
                
            if r["Typ"] == "Pickup":
                
                self.__Pickups.append(le.Pickup(r["Width"], r["Height"], sf.Color(255, 255, 0), sf.Vector2(r["X"], r["Y"])))
                
            if r["Typ"] != "Endzone" and r["Typ"] != "MovingPlatform" and r["Typ"] != "Pickup":
                
                currentObjektList.append(le.LevelEntity(r["Width"], r["Height"], sf.Color(r["ColorR"], r["ColorG"], r["ColorB"]), sf.Vector2(r["X"], r["Y"])))
            
        #aktuellen Highscoreladen     
        cursor.execute("SELECT * FROM highscore")
        db.commit()
          
        result = cursor.fetchone()
        self.__HighscoreTime = sf.milliseconds(result["time"])
        self.__HighscoreScore = result["score"]
        self.__HighscoreDeaths = result["deaths"]
               
        db.close()
        
        #aktuell aktivierter Checkpoint auf den ersten in der Liste setzen = Startpunkt
        self.__currentActiveCheckpoint = self.__Checkpoints[0]
        
    def getCurrentActiveCheckpoint(self):
        return self.__currentActiveCheckpoint
    
    def checkKollisionWithCheckpoint(self, Player):
         
        #Falls SPieler an checkpoint vorbei laeuft diesen aktiv schalten
        for cp in self.__Checkpoints:
            if self.__currentActiveCheckpoint is not cp and hf.kollision(cp.getBoundingRect(), Player.getBoundingRect()):
                self.__currentActiveCheckpoint = cp
                self.__CheckpointActiveSound.volume = gs.GameSettings.VOLUME
                self.__CheckpointActiveSound.play()
                
    def checkKollisionWithPickup(self, Player):
        #Falls Spieler Pickup einsammelt, Score erhoehen und Pickup aus der Liste loeschen
        i = 0
        for p in self.__Pickups:
            if hf.kollision(p.getBoundingRect(), Player.getBoundingRect()):
                
                Player.changeScoreBy(1)
                self.__PickupSound.volume = gs.GameSettings.VOLUME
                self.__PickupSound.play()
                del self.__Pickups[i]
                
            
            i = i + 1
            
    def checkKollisionWithDeathzone(self, Player):
        #Fall Spieler ueber Levelgrenze hinaus oder kollidiert mit Deathzone spieler an gerade aktiven Checkpoint setzen
        #Score abziehn
        for dz in self.__Deathzones:
            if hf.kollision(dz.getBoundingRect(), Player.getBoundingRect()):
                Player.setPosition(self.__currentActiveCheckpoint.getPosition())
                Player.setVelocity(sf.Vector2(0,0))
                self.__DeathSound.volume = gs.GameSettings.VOLUME
                self.__DeathSound.play()
                Player.changeDeathsBy(1)
                
        
        if Player.getPosition().y > 9600 or Player.getPosition().y < -200 or Player.getPosition().x > 9600 or Player.getPosition().x < -200:
        
                Player.setPosition(self.__currentActiveCheckpoint.getPosition())
                Player.setVelocity(sf.Vector2(0,0))
                self.__DeathSound.volume = gs.GameSettings.VOLUME
                self.__DeathSound.play()
                Player.changeDeathsBy(1)
                
        
            
    def getEndZoneRectangle(self):
        return self.__Endzone.getBoundingRect()
    
    def getHighscore(self):
        #aktuellen Highscore zurueckgeben
        return {"time": self.__HighscoreTime, "score": self.__HighscoreScore, "deaths" : self.__HighscoreDeaths}
        
        #