
import sfml as sf
import GameSettings
import HelpFunctions as hf
import os



class MenuItem(object):
    
    """
    Ein Menueeintrag 
    Text mit bestimmter Font und Position auf dem Screen
    """
    
    def __init__(self,string, Font, x, y, size, align = "CENTER"):
        self.Text = sf.Text(string)
        self.string = string
        self.Text.font = Font
        self.Text.character_size = size
        self.Text.position = sf.Vector2(x,y)
        self.Text.color = sf.Color.WHITE
        self.align = align
        
    def getText(self):
        return self.string
    
    def setText(self, string):
        self.Text.string = string
        self.string = string
    
    def setColor(self, Color):
        self.Text.color = Color
        
    def setPosition(self, x, y):
        self.Text.position = sf.Vector2(x,y)
        
    def draw(self, rw):
        
        #Positionieren je nach Ausrichtung auf dem Screen      
        if self.align == "LEFT":
            
            self.setPosition((rw.view.center.x - rw.size.x / 2) + 100, self.getPosition().y)
        
        elif self.align == "RIGHT":
        
            self.setPosition((rw.view.center.x + rw.size.x / 2) - self.Text.global_bounds.width - 100, self.getPosition().y)
        else:
            self.setPosition(rw.view.center.x - self.Text.global_bounds.width/2, self.getPosition().y)
            
            
        
        
        rw.draw(self.Text)

    def getPosition(self):
        return self.Text.position



class Menu(object):
    """
    Klasse um ein einfaches Menue zu erstellen
    Besitzt Ueberschriften und Menueeintraege
    Hintergrund
    abspielbarer Sound beim Menuepunkt wechsel
    """
    
    
    def __init__(self, Font ,BackgroundTexture = "NONE", BackgroundposX = 0, BackgroundposY = 0):
        
        
        self.__menuItems = list()
        self.__headlines = list()
        self.__Font = Font
        self.__currentMenuItem = 0
        
        try: 
            self.__MenuSoundBuffer = sf.SoundBuffer.from_file("./sounds/menusound1.ogg")
        except IOError as e:
            print(e)
            exit(1)
            
        self.__MenuSound = sf.Sound(self.__MenuSoundBuffer)
        #Erstellen des Hintergrunds
        self.__StarBackground = GameSettings.GameSettings.STARBACKGROUND  
        self.__BackgroundImageTexture = BackgroundTexture
        #Falls noch eine Textur gewuenscht diese Laden
        if self.__BackgroundImageTexture != "NONE":
            
            try:
                self.__BackgroundImageTexture = sf.Texture.from_file(BackgroundTexture)
            except IOError as e:
                print(e)
                exit(1)
            
            self.__BackgroundSprite = sf.Sprite(self.__BackgroundImageTexture)
            self.__BackgroundSprite.position = sf.Vector2(BackgroundposX, BackgroundposY)
        
        
  
        
    def __draw(self, rw):
        
        rw.clear()
        #Hintergrund anzeigen
        background = sf.Sprite(self.__StarBackground.texture)
        rw.draw(background)
       
        #Zusatztextur Anteigen
        if type(self.__BackgroundImageTexture) is not str:
            self.__BackgroundSprite.position = sf.Vector2(rw.size.x / 2 - self.__BackgroundSprite.global_bounds.width / 2, self.__BackgroundSprite.position.y)
            rw.draw(self.__BackgroundSprite)
        
        #Alle Ueberschriften anzeigen
        for h in self.__headlines:
            h.position = sf.Vector2(rw.view.center.x - h.global_bounds.width/2, h.position.y)
            rw.draw(h)
        
        #Alle Menueitems anzeigen
        #Gerade ausgewaehltes MenueItem rot zeichnen
        i = 0
        for m in self.__menuItems:
           
            if i is self.__currentMenuItem:
                m.setColor(sf.Color.RED)
            else:
                m.setColor(sf.Color.WHITE)
        
            
            i = i + 1
            m.draw(rw)
        
        rw.display()
                       
        
    def show(self,rw):
        #Eingaben verwalten
        #Solang wie kein Menuepunkt gewaehlt Menue Anzeigen und updaten
        while(rw.is_open):
            
            for event in rw.events:
                #Bei Klick auf X  schliessen
                if type(event) is sf.CloseEvent:
                    rw.close()
                #Nach oben im Menue springen    
                if type(event) is sf.KeyEvent and event.pressed and (event.code is sf.Keyboard.W or event.code is sf.Keyboard.UP):
                    
                    if self.__currentMenuItem > 0:
                        self.__currentMenuItem  = self.__currentMenuItem - 1
                        self.__MenuSound.volume = GameSettings.GameSettings.VOLUME * 0.5
                        self.__MenuSound.play()
                
                #Nach unten im Menue springen
                if type(event) is sf.KeyEvent and event.pressed and (event.code is sf.Keyboard.S or event.code is sf.Keyboard.DOWN):
                    
                    if self.__currentMenuItem < self.__menuItems.__len__() - 1:
                        self.__currentMenuItem  = self.__currentMenuItem + 1
                        self.__MenuSound.volume = GameSettings.GameSettings.VOLUME * 0.5
                        self.__MenuSound.play()
                #MenueItem auswaehlen        
                if type(event) is sf.KeyEvent and event.pressed and event.code is sf.Keyboard.RETURN:
                    self.__MenuSound.volume = GameSettings.GameSettings.VOLUME * 0.5
                    self.__MenuSound.play()
                    #Den Text des gewaehlten MenueItems zurueckgeben
                    return self.__menuItems[self.__currentMenuItem].getText()
              
            self.__draw(rw)
    #Neuen Menueeintrag hinzufuegen
    def addMenuItem(self,String , Font, x, y, size, align = "CENTER"): 
        self.__menuItems.append(MenuItem(String,Font,x,y,size,align))
    #Neue Headline hinzufuegen    
    def addHeadline(self, String, Font, x, y, size, color = sf.Color.WHITE):
        
        t = sf.Text(String)
        t.font = Font
        t.position = sf.Vector2(x,y)
        t.character_size = size
        t.color = color
        self.__headlines.append(t)





class settingsMenu(object):
    
    """
    Klasse um das Optionsmenue zu erstellen
    Veraendert die Aufloesung u. die Lautstaerke
    
    """
    
    def __init__(self, Font, rw):
        
     
        self.__menuItems = list()
        self.__Font = Font
        self.__currentMenuItem = 0
        #Lautstaerke zum verstellen
        self.__Volume = GameSettings.GameSettings.VOLUME
        #Alle Aufloesungen die der Monitor unterstuetzt aufnehmen in die Liste
        self.__vmodes = sf.VideoMode.get_fullscreen_modes()
        #Alle Aufloesungen die keine 32 Bit Farbtiefe haben herrausfiltern 
        self.__changeVModes()
        #Aufloesung zum verstellen
        self.__vmode = GameSettings.GameSettings.VIDEOMODE
        self.__currentSelectedVMode = 0
        
        try:
            self.__MenuSoundBuffer = sf.SoundBuffer.from_file("./sounds/menusound1.ogg")
            
        except IOError as e:
            print(e)
            exit(1)
            
        self.__MenuSound = sf.Sound(self.__MenuSoundBuffer)
        #Text und MenuePunkte erstellen       
        self.headline = sf.Text("Option")
        self.headline.font = Font
        self.headline.character_size = 72
        self.headline.position = sf.Vector2(rw.view.center.x - self.headline.global_bounds.width/2, 50) 
        self.headline.color = sf.Color.BLUE
        
        self.addMenuItem("Resolution: <"+str(self.__vmode.width)+" x "+str(self.__vmode.height)+" x "+str(self.__vmode.bpp)+">", Font, 100, 200, 32)
        self.addMenuItem("Volume: "+str(self.__Volume), Font, 100, 300, 32)
        self.addMenuItem("APPLY", Font, 100, 450, 28)
        self.addMenuItem("BACK", Font, 100, 500, 28)
        
        self.__StarBackground = GameSettings.GameSettings.STARBACKGROUND  
        

        
    def show(self, rw):
        #Eingabe verarbeiten
        while(rw.is_open):
            
            for event in rw.events:
            
                if type(event) is sf.CloseEvent:
                    rw.close()
                    
                if type(event) is sf.KeyEvent and event.pressed and (event.code is sf.Keyboard.W or event.code is sf.Keyboard.UP):
                    
                    #Nach oben im Menue Springen
                    if self.__currentMenuItem > 0:
                        self.__currentMenuItem  = self.__currentMenuItem - 1
                        self.__MenuSound.volume = GameSettings.GameSettings.VOLUME * 0.5
                        self.__MenuSound.play()
                
                
                if type(event) is sf.KeyEvent and event.pressed and (event.code is sf.Keyboard.S or event.code is sf.Keyboard.DOWN):
                    #Nach unten im Menue Springen
                    if self.__currentMenuItem < self.__menuItems.__len__() - 1:
                        self.__currentMenuItem  = self.__currentMenuItem + 1
                        self.__MenuSound.volume = GameSettings.GameSettings.VOLUME * 0.5
                        self.__MenuSound.play()
                        
                #Einstellungen umstellen        
                if type(event) is sf.KeyEvent and event.pressed and (event.code is sf.Keyboard.D or event.code is sf.Keyboard.RIGHT):
                    
                    #Aufloesung ausgewaehlt
                    #Naechste AUflosung waehlen bei D oder Pfeil Rechts druecken
                    if self.__currentMenuItem is 0:
                        if self.__currentSelectedVMode < len(self.__vmodes) - 1:
                            self.__currentSelectedVMode = self.__currentSelectedVMode + 1
                            self.__menuItems[0].setText("Resolution: <"+str(self.__vmodes[self.__currentSelectedVMode].width)+" x "+str(self.__vmodes[self.__currentSelectedVMode].height)+" x "+str(self.__vmodes[self.__currentSelectedVMode].bpp)+">")
                            self.__MenuSound.volume = GameSettings.GameSettings.VOLUME * 0.5
                            self.__MenuSound.play()
                    #Lautstaerke gewaehlt
                    #Lautstraerke erhoehen bei D oder Pfeil Rehcts druecken
                    if self.__currentMenuItem is 1:
                        if self.__Volume < 100:
                            self.__Volume = self.__Volume + 1
                            self.__menuItems[1].setText("Volume: "+str(self.__Volume))
                            self.__MenuSound.volume = self.__Volume
                            self.__MenuSound.play()
                        
                if type(event) is sf.KeyEvent and event.pressed and (event.code is sf.Keyboard.A or event.code is sf.Keyboard.LEFT):
                    
                    #Vorherige Aufloesung waehelen
                    if self.__currentMenuItem is 0:
                        if self.__currentSelectedVMode > 0:
                            self.__currentSelectedVMode = self.__currentSelectedVMode - 1
                            self.__menuItems[0].setText("Resolution: <"+str(self.__vmodes[self.__currentSelectedVMode].width)+" x "+str(self.__vmodes[self.__currentSelectedVMode].height)+" x "+str(self.__vmodes[self.__currentSelectedVMode].bpp)+">")
                            self.__MenuSound.volume = GameSettings.GameSettings.VOLUME * 0.5
                            self.__MenuSound.play()
                    #Lautstaerke verringern     
                    if self.__currentMenuItem is 1:
                        if self.__Volume > 0:
                            self.__Volume = self.__Volume - 1
                            self.__menuItems[1].setText("Volume: "+str(self.__Volume))
                            self.__MenuSound.volume = self.__Volume
                            self.__MenuSound.play()
                        
                if type(event) is sf.KeyEvent and event.pressed and event.code is sf.Keyboard.RETURN:
                    #Falls Enter gedrueckt wenn Menuepunkt "APPLY" ausgewaehlt dann Einstellungen uebernehmen
                    if(self.__currentMenuItem is 2):
                        self.__saveSettings(rw)
                        
                    #Falle Back gewaehlt, Menue verlassen  
                    if(self.__currentMenuItem is 3):
                        return self.__menuItems[self.__currentMenuItem].getText()
                    
                    self.__MenuSound.volume = GameSettings.GameSettings.VOLUME * 0.5
                    self.__MenuSound.play()
              
            self.__draw(rw)
        
    
    def __draw(self, rw):

        rw.clear()
        #Anzeigen des Optionsmenue
        background = sf.Sprite(self.__StarBackground.texture)
        rw.draw(background)
       
        self.headline.position = sf.Vector2(rw.view.center.x - self.headline.global_bounds.width / 2 , self.headline.position.y)
        rw.draw(self.headline)
        i = 0
        for m in self.__menuItems:
           
            if i is self.__currentMenuItem:
                m.setColor(sf.Color.RED)
            else:
                m.setColor(sf.Color.WHITE)
        
            i = i + 1
           
            m.draw(rw)
        
        rw.display()
        
    def addMenuItem(self,String , Font, x, y, size): 
        self.__menuItems.append(MenuItem(String,Font,x,y,size))



    def __saveSettings(self, rw):
        self.__vmode = self.__vmodes[self.__currentSelectedVMode]
        #Falls Aufloesung geaendert wurde, Fenster neu erstellen mit gewaehlter Einstellung
        if self.__vmode.bpp != GameSettings.GameSettings.VIDEOMODE.bpp or self.__vmode.width != GameSettings.GameSettings.VIDEOMODE.width or self.__vmode.height != GameSettings.GameSettings.VIDEOMODE.height:
            GameSettings.GameSettings.VIDEOMODE = self.__vmode
            rw.recreate(GameSettings.GameSettings.VIDEOMODE,"2d Platformer", sf.Style.FULLSCREEN)
            GameSettings.GameSettings.STARBACKGROUND = hf.createStarBackground(self.__vmode.width, self.__vmode.width, 0.001)
            #rw.framerate_limit = GameSettings.GameSettings.FRAMERATE
            rw.mouse_cursor_visible = 0
         
        GameSettings.GameSettings.VOLUME = self.__Volume
        #Einstellungen in SQLite Datenbank speichern
        GameSettings.GameSettings.saveSettings("./settings/settings.sqlite")
        
    #Alle Aufloesungen mit 32 Bit Farbtiefe uebernehmen in auswaehlbare Liste     
    def __changeVModes(self):
        
        temp = list()
        for v in self.__vmodes:
            
            if v.bpp == 32:
                temp.append(v)
        
        self.__vmodes = list()
        for v in temp:
            
            self.__vmodes.append(v)
            
        
                
        
        


#Funktion zum erstellen des Hauptmenues
def initMainMenu( Font, rw):
    
    m = Menu(Font)
    m.addHeadline("Main Menu", Font, 0, 100, 72, sf.Color.BLUE)
    m.addMenuItem("Play", Font, 0, 300, 48)
    m.addMenuItem("Option", Font, 0, 400, 48)
    m.addMenuItem("Quit", Font, 0 , 500, 48)
     
    
    return m

#Funktion zum erstellen des Titlemenues
def initTitleScreen( Font, rw):
    
    m = Menu(Font, "./sprite/title.png",0,200)
    m.addMenuItem("press any key", Font, 0,  rw.size.y - 100, 38)
    
    return m
#Funktion zum erstellen des Levelwahlmenues
def initLevelMenu(Font,rw):
    
    m = Menu(Font)
    m.addHeadline("Levels", Font, 0, 100, 72, sf.Color.BLUE)
    
    Levels = os.listdir("./levels")
    i = 1
    
    for l in Levels:
        if l[-7:] == ".sqlite":
            m.addMenuItem(l[0:-7], Font, 0, (i*25)+200, 24)
            i = i +1
    
    m.addMenuItem("BACK", Font, 0, rw.size.y - 100, 12)
        
    return m

#Funktion zum erstellen des Pausenmenues
def initPausenMenu(Font):
    
    m = Menu(Font)
    
    m.addHeadline("Pause", Font, 0, 100, 72, sf.Color.BLUE)
    
    m.addMenuItem("Resume", Font, 0, 250, 32)
    m.addMenuItem("Restart",Font,0,350,32)
    m.addMenuItem("Choose Level", Font, 0, 450, 32)
    m.addMenuItem("Back to Mainmenu", Font, 0, 550, 32)
    
    return m

#Funktion zum erstellen des Highscoremenue
def initHighscoreMenu(Font, HighscoreDict, rw):
    
    m = Menu(Font)
    
    m.addHeadline("Level Finished", Font, 0, 100, 72, sf.Color.BLUE)
    m.addHeadline("Level: "+HighscoreDict["currentlevelSrc"][:-7][9:], Font, 0, 200, 32)
    #Falls neuer Highscore "NEW BEST TIME" zuesaetzlich anzeigen
    if HighscoreDict["LevelTime"].milliseconds < HighscoreDict["time"].milliseconds:
        m.addHeadline("New Best Time!!", Font, 0, 250, 32, sf.Color.GREEN)
        m.addHeadline("Old Best Time:", Font, 0, 300,28)  
    else:  
        m.addHeadline("Best Time:", Font, 0, 300,28)
        
    m.addHeadline(hf.getTimeString(HighscoreDict["time"]) , Font , 0, 350, 24)
    
    m.addHeadline("Time:", Font, 0, 400,28 )
    
    scoreTime = sf.Time()
    scoreTime.milliseconds = HighscoreDict["PlayerScore"] * 500
    
    HighscoreDict["LevelTime"].milliseconds += scoreTime.milliseconds
    
    m.addHeadline(hf.getTimeString(HighscoreDict["LevelTime"]), Font, 0, 450,24 )
    
    mTime = sf.Time()
    mTime.milliseconds = 500;
    m.addHeadline("- "+str(HighscoreDict["PlayerScore"])+" x "+hf.getTimeString(mTime), Font, 0, 500,20)
    
    HighscoreDict["LevelTime"].milliseconds -= scoreTime.milliseconds
    
    m.addHeadline("= "+hf.getTimeString(HighscoreDict["LevelTime"]), Font, 0, 550,24)
    
    m.addHeadline("Difference:", Font, 0, 600, 28 ) 
    #Differenz zwischen der aktuellen Zeit und dem Highscore errechnen
    dif = sf.Time()
    dif = sf.milliseconds(HighscoreDict["time"].milliseconds - HighscoreDict["LevelTime"].milliseconds)
    
    #Falls Schneller  Plus vor die Zeit setzen sonst Minus
    if HighscoreDict["LevelTime"].milliseconds < HighscoreDict["time"].milliseconds:
        
        m.addHeadline("+"+hf.getTimeString(dif), Font, 0, 650, 24, sf.Color.GREEN ) 
        
    else:
        if dif.seconds < 0:
            
            dif.seconds = dif.seconds * -1
            
        m.addHeadline("-"+hf.getTimeString(dif), Font, 0, 650, 24, sf.Color(128,0,0) ) 
        
        
         
    m.addMenuItem("Play", Font, 0, rw.size.y - 150, 28, "LEFT")
    m.addMenuItem("Back to Mainmenu", Font, 0, rw.size.y - 100, 28, "LEFT")
    
    return m
   
    
   