

import sfml as sf
import sqlite3
import HelpFunctions as hf

class GameSettings(object):
    """
    Beinhaltet alle Einstellungen des Spiels 
    als Klassenvariablen
    """   
    FRAMERATE = 0
    VIDEOMODE = sf.VideoMode(1280,1024)
    GRAVITY = 0
    PLAYERSPEED = 0
    PLAYERJUMPSPEED = 0
    VOLUME = 0
    
    JUMPBUTTON = sf.Keyboard.SPACE
    LEFT = sf.Keyboard.A
    RIGHT = sf.Keyboard.D
    
    try:
        MENUMUSIC = sf.Music.from_file("./sounds/MenuMusic2.ogg")
        GAMEMUSIC = sf.Music.from_file("./sounds/GameMusic.ogg")
    except IOError as e:
            print(e)
            exit(1)
    
    MENUMUSIC.loop = True
    GAMEMUSIC.loop = True
    
    STARBACKGROUND = hf.createStarBackground(1, 1, 0.001)
    
    @staticmethod
    def saveSettings(SettingsDatabase):
        #Statische Methode um die Einstellungen in SQLite Datenbank zu speichern
        db = sqlite3.connect(SettingsDatabase)
        cursor = db.cursor()
        settings = [(GameSettings.FRAMERATE, GameSettings.PLAYERSPEED, GameSettings.PLAYERJUMPSPEED, GameSettings.GRAVITY, GameSettings.VOLUME, GameSettings.VIDEOMODE.width, GameSettings.VIDEOMODE.height, GameSettings.VIDEOMODE.bpp)]
        cursor.executemany("UPDATE settings SET framerate=? , playerspeed=? , playerjumpspeed=?, gravity=?, volume=?, vmodewidth=?, vmodeheight=?, vmodebpp=?", settings)
        db.commit()
        db.close()
        
    @staticmethod
    def loadSettings(SettingsDatabase):
        #Statische Methode laed alle Einstellungen aus SQLite Datenbank
        #Leadt die Daten in ein Dictionary
        db = sqlite3.connect(SettingsDatabase)
        db.row_factory = sqlite3.Row
        cursor = db.cursor()
        cursor.execute("SELECT * FROM settings")
        db.commit()
        settings = cursor.fetchone()
        GameSettings.FRAMERATE =  settings["framerate"]
        GameSettings.GRAVITY = settings["gravity"]
        GameSettings.PLAYERJUMPSPEED = settings["playerjumpspeed"]
        GameSettings.PLAYERSPEED = settings["playerspeed"]
        GameSettings.VOLUME = settings["volume"]
        GameSettings.VIDEOMODE = sf.VideoMode(settings["vmodewidth"], settings["vmodeheight"], settings["vmodebpp"])
        db.close()
        GameSettings.STARBACKGROUND = hf.createStarBackground(GameSettings.VIDEOMODE.width, GameSettings.VIDEOMODE.height, 0.001)
         


   